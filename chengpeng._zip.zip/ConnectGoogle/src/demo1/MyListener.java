/**
 * @author Chengpeng Li E-mail:chengp@unc.edu
 * Implements customized listener
 */
package demo1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class MyListener implements ActionListener,ItemListener,ListSelectionListener {

   private String countryname;
   private JTextArea jta;
   private String categoryname;
   private String range;
    public MyListener(JTextArea jta)
    {this.jta=jta;}
    
    /**
     * listen for 1) JButton has been clicked  or 2) JTextField has input 
     */
	public void actionPerformed(ActionEvent e) {
		Object o=e.getSource();
		if(o instanceof JTextField)
		{
		countryname=(((JTextField) o).getText());
	
		try {
			
			   Class.forName("cdata.jdbc.googlesheets.GoogleSheetsDriver");
			   Connection conn=DriverManager.getConnection("jdbc:googlesheets:InitiateOAuth=GETANDREFRESH;Header=True;SupportEnhancedSQL=False");
			   Statement stat=conn.createStatement();
			   //Use SQLFunction
			   ArrayList<String> array=SQLFunction.getResult1( conn, stat,countryname);
		       //invalid input
			   if(array.size()==0) jta.setText("No Data found");
			   //append data to JTextArea
		    else{
		    	jta.setText("");
				jta.append("ProductName:\n");
		    	for(String s:array){
		    	jta.append(s);
		    	jta.append("\n");
		     }
		    }
		
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 
		}
	
		else if(o instanceof JButton)
		{
			jta.setText("");
			jta.append("CountryName         OrderPrice\n\n");
			try {
				  Class.forName("cdata.jdbc.googlesheets.GoogleSheetsDriver");
				  Connection conn=DriverManager.getConnection("jdbc:googlesheets:InitiateOAuth=GETANDREFRESH;Header=True;SupportEnhancedSQL=False");
				  Statement stat=conn.createStatement();
				  //Use SQLFucntion
				  TreeMap<String,Float> result=SQLFunction.getView(conn, stat);
			      //append data to JTextArea
			      for(Map.Entry<String, Float> entry:result.entrySet()){
			    	// if(entry.getKey().equals("PriceOrder")) System.out.println("ssssss");
			    	 jta.append(entry.getKey()+"======="+entry.getValue());
			    	 jta.append("\n");
			     }
			
			} catch (ClassNotFoundException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	 
    	
		
	}
    /**
     * Listen for JCombo's item state change event
     */
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		if(e.getStateChange() == ItemEvent.SELECTED)
		{JComboBox cb=(JComboBox)e.getSource();
		String s=(String)cb.getSelectedItem();
		categoryname=s;
		
		try {
			
			   Class.forName("cdata.jdbc.googlesheets.GoogleSheetsDriver");
			   Connection conn=DriverManager.getConnection("jdbc:googlesheets:InitiateOAuth=GETANDREFRESH;Header=True;SupportEnhancedSQL=False");
			   Statement stat=conn.createStatement();
			   //Use SQLFucntion
			   ArrayList<String> array=SQLFunction.getResult2( conn, stat,categoryname);
		       //Append data to JTextArea
			   jta.setText("");
			   jta.append("ProductName:\n");
		       for(String str:array){
		       jta.append(str);
		       jta.append("\n");
		     
		    }
		
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		}
	}
   
	/**
	 * listen for JListSelction Event
	 */
	@Override
	public void valueChanged(ListSelectionEvent e) {
		// TODO Auto-generated method stub
		if(!e.getValueIsAdjusting())
		{	
		JList jl=(JList)e.getSource();
		String cl=(String) jl.getSelectedValue();	
		jta.setText("");
		jta.append("ProductName:\n");
		range=cl;
		ArrayList<String> array=null;
		//flag to check where item is ">100" or not 
		boolean flag=true;
		if(cl.equals(">100"))  flag=false;
		jta.setText("");
		jta.append("ProductName:\n");
		try {
			
			   Class.forName("cdata.jdbc.googlesheets.GoogleSheetsDriver");
			   Connection conn=DriverManager.getConnection("jdbc:googlesheets:InitiateOAuth=GETANDREFRESH;Header=True;SupportEnhancedSQL=False");
			   Statement stat=conn.createStatement();
			   //when flag=false, min should be 100, max should be Float.MAX_VALUE
			   if(!flag)
			   //Use SQLFunction
			    array=SQLFunction.getResult3( conn, stat,100,Float.MAX_VALUE);
			   // parse the string to get min and max value
			   else
			   {   String[] split=range.split("-");
				   //Use SQLFunction
			       array=SQLFunction.getResult3(conn, stat, Float.parseFloat(split[0]), Float.parseFloat(split[1]));}
		            if(array.size()==0) jta.append("Not found");
		            else{for(String str:array){
		    	         jta.append(str);
		    	         jta.append("\n");
		     }
		    }
		
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	}
}
