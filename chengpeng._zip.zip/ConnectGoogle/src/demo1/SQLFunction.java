/**
 * @author Chengpeng Li E-mail:chengp@unc.edu
 * Implement SQLfunctions which have been set to false
 */
package demo1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class SQLFunction {

  /**
   * Implement A) function------Search by input CountryName 
   * @param con  
   * @param stat
   * @param country
   * @return  ArrayList which includes valid ProductName
   */
	public static ArrayList<String> getResult1(Connection con,Statement stat,String country)
	{       ArrayList<String> array=null;
	    
		try {
			array=new ArrayList<String>();	
			Set<String> set=new HashSet();
			String str="select * from  Northwind_Suppliers ";
			String strs="select * from Northwind_Products";
			boolean ret = stat.execute(str);
			ResultSet s1=stat.getResultSet();
			//Use set to store which SupplierID is valid for required country
			while(s1.next()){
				 if(s1.getString("Country").equals(country))
				 set.add((s1.getString("SupplierID")));
			
		}
			boolean res=stat.execute(strs);
			ResultSet s2=stat.getResultSet();
  		    // valid SupplierID from ProductTable are all stored in set .
			while(s2.next()){
  		    	if(set.contains(s2.getString("SupplierID")))
  		    	{
  		    		System.out.println(s2.getString("SupplierID"));
  		    		array.add(s2.getString("ProductName"));}
  		    }
  		    System.out.println(array.size());
		 
		   }catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		 }
		
		
		return array;		
	}
	
	/**
	 * Implement B) function ----Search by CategoryName
	 * @param con
	 * @param stat
	 * @param category
	 * @return ArrayList includes valid ProductName
	 */
	
	public static ArrayList<String> getResult2(Connection con,Statement stat,String category)
	{     ArrayList<String> array=null;
		try {
			array=new ArrayList<String>();	
			Set<String> set=new HashSet();
			String str="select * from  Northwind_Categories ";
			String strs="select * from Northwind_Products";
			boolean ret = stat.execute(str);
			ResultSet s1=stat.getResultSet();
            //Use set to store valid CategoryId for CategoryName user clicked
			while(s1.next()){
			 if(s1.getString("CategoryName").equals(category))
				 set.add((s1.getString("CategoryID")));
			
		}
			boolean res=stat.execute(strs);
			//Valid CategoryID are all stored in set
  		    ResultSet s2=stat.getResultSet();
  		    while(s2.next()){
  		    	if(set.contains(s2.getString("CategoryID")))
  		    	{
  		    		array.add(s2.getString("ProductName"));}
  		    }
  		   System.out.println(array.size());
		 
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return array;		
	}
	
	/**
	 * Implement B) function ----Search by price range
	 * @param con
	 * @param stat
	 * @param min
	 * @param max
	 * @return   ArrayList includes valid ProductName
	 */
	public static ArrayList<String> getResult3(Connection con,Statement stat,float min,float max)
	{   ArrayList<String> array=null;
		try {
			array=new ArrayList<String>();	
			String strs="select * from Northwind_Products";
			boolean res=stat.execute(strs);
			ResultSet s2=stat.getResultSet();
  		    while(s2.next()){
  		    	float price=Float.parseFloat(s2.getString("UnitPrice"));
  		    	//Check price range
  		    	if(price>min && price<=max)
  		    	{   
  		    		//store valid productname to arraylist
  		    		array.add(s2.getString("ProductName"));}
  		        }
  		    System.out.println(array.size());
		 
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return array;		
	}
	
	/**
	 * Implement C) function-------View average price per country alphabetically
	 * @param con
	 * @param state
	 * @return TreeMap which includes CountryName and its related average price
	 */
	
	public static TreeMap<String,Float>  getView(Connection con,Statement state){
		try {
			TreeMap<String,Float> finalmap=new TreeMap<>();
			//For hashMap Entry, key is countryName,value is int array. array[0] stores the total price, array[1] stores total count.
			HashMap<String,float[]> map=new HashMap<>();
			Class.forName("cdata.jdbc.googlesheets.GoogleSheetsDriver");
			Connection conn=DriverManager.getConnection("jdbc:googlesheets:InitiateOAuth=GETANDREFRESH;Header=True;SupportEnhancedSQL=False");
			Statement stat=conn.createStatement();
            String strs="select * from Northwind_Orders";			
			boolean res=stat.execute(strs);			
  		    ResultSet s2=stat.getResultSet();
  		    while(s2.next()){
  		    	float price=Float.valueOf(s2.getString("OrderPrice"));
  		    	String country=s2.getString("ShipCountry");
  		    	if(!country.equals(""))
  		    	{if(map.containsKey(country)){
  		    		float[] values=map.get(country);
  		    		values[0]+=price;
  		    		values[1]+=1;
  		    		map.put(country,values);
  		    	}
  		    	else{
  		    	  //First time put this country data
  		    		map.put(country, new float[2]);
  		    		float[] values=map.get(country);
  		    		values[0]+=price;
  		    		values[1]+=1;
  		    		map.put(country,values);
  		    	}
  		    }}
  		    //Use TreeMap to sort key automatically 
  		    for(Map.Entry<String,float[]> entry:map.entrySet())
  		    {   float per_price=entry.getValue()[0]/entry.getValue()[1];
  		    	finalmap.put(entry.getKey(),per_price);
  		    	
  		    	
  		    }
  		    return finalmap;
			
			
		} catch (ClassNotFoundException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		
		
		
		return null;		
	}
	
	
}
