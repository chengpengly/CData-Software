/**
 * @author Chengpeng Li E-mail:chengp@unc.edu
 * Application main file
 */
package demo1;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class Application {
    public static void main(String[] args) {
         //create Application GUI
    	JFrame main_frame = new JFrame();
		main_frame.setTitle("Color Picker");
		main_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel main_panel = new JPanel();
		main_panel.setLayout(new BorderLayout());
		
		main_frame.setContentPane(main_panel);
		
		JPanel j1=new JPanel();
		JLabel jl=new JLabel("Search by Country Name(UpperCase)");
		JTextField jtf=new JTextField(5);
		
		
		JTextArea jta=new JTextArea(20,20);
	
		JScrollPane jsp=new JScrollPane(jta);
		
		JLabel jl1=new JLabel("Search by Catogary name");
		String[] name={"Beverages 2","Condiments","Confections","Dairy Products","Grains/Cereals","Meat/Poultry","Produce","Seafood"};
		JComboBox combo=new JComboBox(name);
	
		JLabel jl2=new JLabel("Search by Product Unit Price range");
		JTextField jtf2=new JTextField(5);
		String[] price={"0-20","20-40","40-60","60-80","80-100",">100"};
		JList list=new JList(price);
		JButton jb=new JButton("Click to see the Country Average Order Price");
		jsp.setBounds(20, 70, 200, 100);
		jta.setLineWrap(true);
		jtf.setEditable(true);
		jta.setWrapStyleWord(true);
		
       // Create customernized listener  for all actions 
		MyListener mylistener=new MyListener(jta);	
		// register components with listener 
		jtf.addActionListener(mylistener);
		combo.addItemListener(mylistener);
		jb.addActionListener(mylistener);
		list.addListSelectionListener(mylistener);
		j1.add(jl);
		//Layout components 
		j1.add(jtf,BorderLayout.NORTH);
		j1.add(jl1,BorderLayout.NORTH);
		j1.add(combo,BorderLayout.NORTH);
		j1.add(jl2,BorderLayout.NORTH);
		j1.add(list,BorderLayout.NORTH);
		j1.add(jb,BorderLayout.WEST);		
	     j1.add(jsp,BorderLayout.CENTER);
	
        //JFrame add JPanel
		main_panel.add(j1);
        //Pack all components 
		main_frame.pack();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		main_frame.setSize(screenSize.width, screenSize.height);
	
	
		main_frame.setVisible(true);


    	
  	
    	
    } 	
}
